import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products:any[]
  constructor() {
    this.products = [
      {
        title:"Tailored Jeans",
        price:19.99,
        img:"https://source.unsplash.com/200x200",
        desc:"Some text about the jeans. Super slim and comfy lorem ipsum lorem jeansum. Lorem jeamsun denim lorem jeansum.",
      },
      {
        title:"Tailored Jeans For Free!",
         price:19.99,
        img:"https://source.unsplash.com/200x200",
        desc:"Some text about the jeans. Super slim and comfy lorem ipsum lorem jeansum. Lorem jeamsun denim lorem jeansum.",
      },
      {
        title:"Another Tailored Jeans!",
         price:24.99,
        img:"https://source.unsplash.com/200x200",
        desc:"Some text about the jeans. Super slim and comfy lorem ipsum lorem jeansum. Lorem jeamsun denim lorem jeansum.",
      },
      
    ]
   }

  ngOnInit(): void {
  }

}
