import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-btn',
  templateUrl: './contact-btn.component.html',
  styleUrls: ['./contact-btn.component.css']
})
export class ContactBtnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
